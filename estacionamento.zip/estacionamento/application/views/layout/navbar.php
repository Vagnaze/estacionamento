
            <header class="header-top" header-theme="light">
               
                <section class="nav-top">
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    
    
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarDefault">
        
        <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link active" href="home" style="color: #FFF"><i class="fa fa-home" aria-hidden="true"></i></a>
                </li>
            </ul>
            <?php if($this->session->userdata("utilizador_logado")) : ?>
            <?php echo $this->session->utilizador;?>
             
                <a href="login/logout" class="nav-link" style="color: #FF0000;">Terminar Sessão</a>
            <?php else : ?>
                <a href="registo" class="nav-link" style="color: #FFF;"><i class="fa fa-user-plus" aria-hidden="true"></i></a>
                <a href="login" class="nav-link" style="color: #FFF;"><i class="fa fa-user" aria-hidden="true"></i></a>
            <?php endif ?>
        </ul>
    </div>
</nav>
</section>
            </header>
