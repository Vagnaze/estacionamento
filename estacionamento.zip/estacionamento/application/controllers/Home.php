<?php

defined('BASEPATH') OR exit('Ação não permitida'); //proteger o arquivo de acesso direto

class Home extends CI_Controller{

    public function index(){

     $this->load->view('home/index');   

    }

    
}