<?php

defined('BASEPATH') OR exit('Ação não permitida'); //proteger o arquivo de acesso direto

class Home extends CI_Controller{

    public function index(){

        $data = [
            'titulo' => 'Home'
        ];
     
     $this->load->view('layout/navbar', $data);
     $this->load->view('layout/header', $data);       
     $this->load->view('pages/index');
     $this->load->view('layout/footer');
    
    }

    
}