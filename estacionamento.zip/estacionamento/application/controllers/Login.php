<?php

defined('BASEPATH') OR exit('Ação não permitida'); //proteger o arquivo de acesso direto

class Login extends CI_Controller{

    public function index() {
        
        $this->load->view('layout/navbar', $data);
        $this->load->view('layout/header', $data);       
        $this->load->view('auth/login', $data);
        $this->load->view('layout/footer', $data);    
       
    }
    public function logar()
    {
    	$this->load->model("utilizadores_model");
    	$username = $this->input->post("username");
    	$password = md5($this->input->post("password"));
    	$utilizador = $this->utilizadores_model->loginUtilizadores($username, $password);
    	if ($utilizador) {
    		$this->session->set_userdata("utilizador_logado", $utilizador);
    		$this->session->set_flashdata("success", "Login com sucesso!");
    		redirect("/");
    	}else{
    		$this->session->set_flashdata("danger", "Username ou Password incorreta!");
    		redirect("login");
    	}
    }
    public function logout(){
    	//session_destroy();
    	$this->session->unset_userdata("utilizador_logado");
    	//$this->session->set_flashdata("success", "Deslogado com sucesso!");
    	redirect("/");

    }
}
